# Broken-Elytras-F32x
Gives worn broken elytras visual tears.
