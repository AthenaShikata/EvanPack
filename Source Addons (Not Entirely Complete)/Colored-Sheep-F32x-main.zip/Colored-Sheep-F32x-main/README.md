# Colored-Sheep-F32x
Makes every part of the sheep's wool colored, including when it's sheared.
