# Jappa-Spawn-Eggs-F32x
Gives spawn eggs a more Jappa design with more vibrant colors, insipired by the 3 Jappa-ish spawn eggs from Bedrock Edition.
