# Dustpans-Faithful-Emissive-Faithful-32x
A more faithful Emissive Textures Add-on for Faithful-32x (https://www.faithfulpack.net)


=== GUILDINES FOR SUBMISSION: ===
1) All texture submissions MUST be minor edits of the base Faithful 32x (as decided by the owner(s) of this pack) resource pack.
2) The only partial transparencies should be on items, although full opacity/transparencies are preferred.
3) Please Index, it's not necessary but much appreciated.
